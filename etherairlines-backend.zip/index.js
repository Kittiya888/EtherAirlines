const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

const bookings = {
  "AB1234": {
    lastName: "smith",
    status: "Confirmed",
    flightNumber: "ET203",
    date: "2025-05-02",
    origin: "BKK (Suvarnabhumi)",
    destination: "HKT (Phuket)",
    seat: "12A",
    class: "Economy"
  },
  "CD5678": {
    lastName: "tanaka",
    status: "Pending",
    flightNumber: "ET105",
    date: "2025-06-10",
    origin: "BKK (Suvarnabhumi)",
    destination: "CNX (Chiang Mai)",
    seat: "4A",
    class: "Business"
  }
};

app.get('/bookings/status', (req, res) => {
  const { pnr, lastName } = req.query;
  const booking = bookings[pnr];
  if (booking && booking.lastName.toLowerCase() === lastName.toLowerCase()) {
    res.json(booking);
  } else {
    res.status(404).json({ error: "Booking not found" });
  }
});

app.get('/', (req, res) => {
  res.send('Ether Airlines Booking API is running.');
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});